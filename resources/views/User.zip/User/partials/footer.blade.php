<div id="footer">
        <div class="footer-1">
            <div style="padding: 10px;" class="tuvanmuahang">
                <i style="font-size: 40px;float: left;color: rgb(96, 177, 38);"class="fa-solid fa-headset"></i>
                <strong style="display:block;padding-left:60px;color: rgb(96, 177, 38);">Tư vấn đặt hàng</strong>
                <span style="padding-left:20px;" >0835286779</span>
            </div>
            <div style="padding: 10px;" class="tuvanbaohang">
                <i style="font-size: 40px;float: left;color: rgb(96, 177, 38);"class="fa-solid fa-headset"></i>
                <strong style="display:block;padding-left:60px;color: rgb(96, 177, 38);">Tư vấn bảo hàng</strong>
                <span style="padding-left:20px;" >0835286779</span>
            </div>
            <div style="padding: 10px;" class="lhequaemail">
                <i style="font-size: 40px;float: left;color: rgb(96, 177, 38);"class="fa-solid fa-headset"></i>
                <strong style="display:block;padding-left:60px;color: rgb(96, 177, 38);">Liên hệ qua Email</strong>
                <span style="padding-left:20px;" >0835286779</span>
            </div>
        </div>
        <div class="footer-2">
            <div class="thongtin1">
                <h2 style="margin-left: 45px;">CỬA HÀNG ĐẶC SẢN HÀ NỘI THANH PHƯƠNG</h2>
                <span><i style="color: rgb(96, 177, 38);padding: 5px;" class="fas fa-user-check"></i></i>Người đại diện: Đỗ Văn Yên/MST:0314080990</span>
                <span><i style="color: rgb(96, 177, 38);padding: 5px;"class="fas fa-phone"></i> Hotline: 0835286779</span>
                <span><i style="color: rgb(96, 177, 38);padding: 5px;"class="fas fa-map-marker-alt"></i> CN1: 229 Bạch Đằng, P3, Q Gò Vấp (Giờ làm việc: 7h-21h)</span>
                <span><i style="color: rgb(96, 177, 38);padding: 5px;"class="fas fa-map-marker-alt"></i>CN2: 86B Nguyễn Thông, P9, Quận 3 (Giờ làm việc: 8h30-20h30)</span>
                <span><i style="color: rgb(96, 177, 38);padding: 5px;"class="fas fa-map-marker-alt"></i>CN3: Coming soon</span>
            </div>
            <div class="thongtin2">
                <div class="chinhsachkh">
                    <h2>CHÍNH SÁCH KHÁCH HÀNG</h2>
                    <ul>
                        <li><a href="#">Chính sách bảo mật thông tin</a></li>
                        <li><a href="#">Quy định và hình thức thanh toán</a></li>
                        <li><a href="#">Chính sách đổi trả hàng</a></li>
                        <li><a href="#">Chính sách giao nhận</a></li>
                    </ul>
                </div>
                <div class="ketnoifb">
                    <h2>KẾT NỐI FACEBOOK</h2>
                    <div class="img-fb">
                        <a href="https://www.facebook.com/dacsanhanoithanhphuong/"> <img style="width: 30%;height: 40%; margin-top: 10px;margin-left: 10px;float: left;" src="img/img-DS.jpg" alt="">
                        </a>
                        <div class="img-chu">
                            <a style=" text-decoration: none;" href="https://www.facebook.com/dacsanhanoithanhphuong/">Đặc Sản Hà Nội Thanh Phương</a>
                            <b style="font-size: 14px; color: white;display: block;">4,5K người theo dõi</b>


                        </div>
                        <div class="theodoitrang">
                            <a style="color: black;margin-left: 10%;text-decoration: none;" href="https://www.facebook.com/dacsanhanoithanhphuong/"><i style="font-size: 16px; color:rgb(55, 87, 152);margin-right: 8px;padding-top: 6px;" class="fa-brands fa-square-facebook"></i>Theo dõi trang</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="footer-3">
            <div class="info-giaycn">
                <h3><i style="color:rgb(96, 177, 38)" class="fas fa-file-alt"></i> Giấy CNĐKKD: 41M8032573 do ủy bản nhân dân quận Gò Vấp ký ngày 25/10/2016</h3>
            </div>
            <div class="img-bcthuong">
                <a href="#">
                    <img style="width: 30%;height: 100%;float: right;" src="img/bocongthuong.png" alt="">
                </a>
            </div>
        </div>
        <div class="footer-4">
            <div class="banquyen">
                <span>Bản quyền 2022 &copy; <a class="text-warning">Cửa Hàng Đặc Sản Hà Nội Thanh Phương - Đặc Sản Hà Nội</a> </span>
            </div>
            <div class="thietke">
                <span>Thiết kế và phát triển bởi<a class="text-warning">Thanh Phương</a> </span>
            </div>
        </div>
    </div>
    <script src="js/SanPham.js"></script>
    <!-- End footer -->
        <!--  -->
        <div class="image">

            <img id="img" onclick="changeImage()" src="img/icon-phone2.png" alt="">

        </div>