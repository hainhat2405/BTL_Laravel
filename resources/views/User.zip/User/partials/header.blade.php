<div id="header">
        <div id="img-logo">
            <a href="{{ route('home') }}"><img src="img/logo_thanh phuong.png" alt="" class="logo"></a>
        </div>

        <ul class="main-nav">
            <li><a href="{{ route('home') }}">Trang chủ</a></li>
            <li><a href="{{ route('gioiThieu') }}">Giới thiệu</a></li>
            <li><a href="#">Hướng dẫn mua hàng</a></li>
            <li><a href="{{ route('tinTuc') }}">Tin tức đặc sản</a></li>
            <li><a href="#">Liên hệ</a></li>
        </ul>
        <div style="padding: 10px;" class="icon-dathang">
            <i style="font-size: 40px;float: left;color: rgb(96, 177, 38);margin-right: 10px;margin-top: 20px;"class="fa-solid fa-headset"></i>
            <strong style="display:block;color: rgb(96, 177, 38);margin-top: 20px;">Đặt hàng</strong>
            <span>0835286779</span>
        </div>
    </div>
